﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication19.Models;

namespace WebApplication19.ViewModel
{
    public class multipleData
    {
        public IEnumerable< user> users { get; set; }
        public IEnumerable<register> registers { get; set; }





    }
}